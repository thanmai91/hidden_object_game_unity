using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelBackButtonManager : MonoBehaviour
{
    public void GoToLevelSelection()
    {
        SceneManager.LoadScene("InstructionsScene");
    }
}
