using UnityEngine;
using TMPro; // Make sure to include this for TextMeshPro
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class GridCell : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerClickHandler
{
    public int x;
    public int y;
    public int cellNumber; // Cell number to display

    private Image cellImage;
    private Outline cellOutline;
    private Color defaultBorderColor;
    private Color highlightBorderColor;
    private GridManager gridManager;
    private TMP_Text cellText; // Use TMP_Text instead of Text

    public void Initialize(int x, int y, int number, Color defaultColor, Color highlightColor, GridManager manager)
    {
        this.x = x;
        this.y = y;
        this.cellNumber = number;
        this.defaultBorderColor = defaultColor;
        this.highlightBorderColor = highlightColor;
        this.gridManager = manager;

        // Ensure gridManager is assigned if null
        if (gridManager == null)
        {
            gridManager = FindObjectOfType<GridManager>();
            if (gridManager == null)
            {
                Debug.LogError("GridManager not found in the scene.");
            }
        }

        // Initialize components
        cellImage = GetComponent<Image>();
        cellOutline = GetComponent<Outline>();

        // Get the TextMeshPro component
        cellText = GetComponentInChildren<TMP_Text>();
        if (cellText == null)
        {
            Debug.LogError("TextMeshPro component is missing in the GridCell prefab.");
        }
        else
        {
            cellText.text = "";
        }

        SetBorderColor(defaultBorderColor);
        Debug.Log("Assigning number " + cellNumber + " to cell at position (" + x + "," + y + ")");
    }

    public void SetCellNumber(int number)
    {
        if (cellText != null)
        {
            cellText.text = number.ToString(); // Display the number on the cell
            Debug.Log("Set cell number: " + number + " at (" + x + "," + y + ")");
        }
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        SetBorderColor(highlightBorderColor);

        // Add the cell to the path when the mouse enters the cell, only if the game is ongoing
        if (gridManager != null && !gridManager.gameEnded)
        {
            gridManager.AddCellToPath(this);
        }
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        SetBorderColor(defaultBorderColor);
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if (gridManager != null && !gridManager.gameEnded)
        {
            if (this == gridManager.currentTargetCell)
            {
                // Execute target-found behavior
                gridManager.OnTargetFound();
            }
            else
            {
                // Optionally handle non-target click (e.g., feedback or changing the state of the cell)
                Debug.Log("Cell clicked, but not the target.");
            }
        }
        else if (gridManager == null)
        {
            Debug.LogError("GridManager is not assigned in the GridCell script.");
        }
    }

    public void SetCellColor(Color color)
    {
        if (cellImage != null)
        {
            cellImage.color = color;
        }
    }

    public void SetBorderColor(Color color)
    {
        if (cellOutline != null)
        {
            cellOutline.effectColor = color;
        }
    }
}
