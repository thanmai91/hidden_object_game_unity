using UnityEngine;
using UnityEngine.SceneManagement;

public class InstructionsTimer : MonoBehaviour
{
    public float displayTime = 5f; // Adjust for how long instructions are shown

    void Start()
    {
        Invoke("LoadLevelSelection", displayTime);
    }

    void LoadLevelSelection()
    {
        SceneManager.LoadScene("LevelSelectionScene");
    }
}
