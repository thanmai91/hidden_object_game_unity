using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
using System.Collections;

public class LevelManager : MonoBehaviour
{
    public TMP_Text gameOverText;

    void Start()
    {
        HideGameOverMessage();
    }

    public void LoadNextLevel()
    {
        int currentSceneIndex = SceneManager.GetActiveScene().buildIndex;
        int nextSceneIndex = currentSceneIndex + 1;

        if (nextSceneIndex < SceneManager.sceneCountInBuildSettings)
        {
            SceneManager.LoadScene(nextSceneIndex);
        }
        else
        {
            Debug.Log("No more levels. Showing game over message.");
            ShowGameOverMessage();
        }
    }

    public void ShowGameOverMessage()
    {
        if (gameOverText != null)
        {
            StartCoroutine(FadeInGameOverText());
        }
    }

    public void HideGameOverMessage()
    {
        if (gameOverText != null)
        {
            Color color = gameOverText.color;
            color.a = 0;
            gameOverText.color = color;
        }
    }

    IEnumerator FadeInGameOverText()
    {
        Color color = gameOverText.color;
        float elapsedTime = 0f;
        float fadeDuration = 2f;

        while (elapsedTime < fadeDuration)
        {
            elapsedTime += Time.deltaTime;
            color.a = Mathf.Lerp(0, 1, elapsedTime / fadeDuration);
            gameOverText.color = color;
            yield return null;
        }
    }
}
