using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class LevelSelectionManager : MonoBehaviour
{
    public void LoadLevel1()
    {
        SceneManager.LoadScene("Level1");
        SaveLevelDetails(1); // Save level 1 details
    }

    public void LoadLevel2()
    {
        SceneManager.LoadScene("Level2");
        SaveLevelDetails(2); // Save level 2 details
    }

    public void LoadLevel3()
    {
        SceneManager.LoadScene("Level3");
        SaveLevelDetails(3); // Save level 3 details
    }

    private void SaveLevelDetails(int level)
    {
        List<string> rowData = new List<string>
        {
            "Level " + level, // Level information
            "Target 1", // Target (assuming only one target for simplicity)
            "", // Path will be updated during the game
            "0", // Placeholder for time taken
            "0" // Placeholder for number of cells
        };

        // Save this initial data to CSV
        FindObjectOfType<CSVManager>().SaveToCSV(rowData);
    }

    public void GoBack() => SceneManager.LoadScene("LevelSelectionScene");
    public void GoToInstructions() => SceneManager.LoadScene("InstructionsScene");
    public void GoToLogin() => SceneManager.LoadScene("SampleScene");
}