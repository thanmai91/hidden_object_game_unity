using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class CSVManager : MonoBehaviour
{
    private string filePath = "Assets/Resources/game_data.csv"; // Define file path

    // Method to save data to CSV
    public void SaveToCSV(List<string> rowData)
    {
        // Check if file exists
        bool fileExists = File.Exists(filePath);

        // Open file for writing or create it if it doesn't exist
        using (StreamWriter writer = new StreamWriter(filePath, true))
        {
            // Write headers if the file is new
            if (!fileExists)
            {
                writer.WriteLine("Level,Target,Object Path,Time Taken,Number of Grid Cells");
            }

            // Write the data row
            writer.WriteLine(string.Join(",", rowData));
        }
    }
}