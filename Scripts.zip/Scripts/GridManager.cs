using System.Collections.Generic;
using TMPro;
using System.Collections;
using UnityEngine;
using System.Linq;

using UnityEngine.UI; // Import UI namespace for using Button

public class GridManager : MonoBehaviour
{
    public GameObject gridCellPrefab; // Prefab for grid cells
    public int gridWidth = 10; // Width of the grid
    public int gridHeight = 10; // Height of the grid
    public Transform gridParent; // Parent object for the grid
    public List<GameObject> targetObjects; // List of targets
    private int currentTargetIndex = 0; // Tracks the current target
    public GridCell currentTargetCell; // The current target cell
    public float startTime; // Timer start time
    public TMP_Text timeText; // Text UI for displaying time
    public TMP_Text levelText; // Text UI for displaying level information
    public TMP_Text gameOverText; // Text UI for displaying game over message
    public GameObject goBackButton; // Reference to the Go Back button
    public LineRenderer lineRenderer; // Line renderer for the path
    public Light roomLight; // Ambient room light
    public Light targetLight; // Light for highlighting targets
    public GameObject darkOverlay;
    public Button darkenButton; // Reference to the darken button
    public bool isSceneDarkened = false;

    private List<GridCell> path = new List<GridCell>(); // Path for tracking mouse movements
    public bool gameEnded = false; // Flag to check if the game has ended
    public CSVManager csvManager; // Reference to CSVManager

    // List to store time taken for each target
    private List<float> timesTaken = new List<float>();

    // Variables to store original colors for restoration
    private Color originalRoomLightColor;
    private Color originalTargetLightColor;
    private float originalRoomLightIntensity;
    private float originalTargetLightIntensity;

    void Start()
    {
        csvManager = FindObjectOfType<CSVManager>();// Get reference to CSVManager
        levelText.gameObject.SetActive(true); // Show level text at the start
        StartCoroutine(HideLevelTextAfterDelay(2f));

        ResetLevel(); // Initialize the level at the start
        CreateGrid(); // Create the grid layout

        // Set up button listener
        darkenButton.onClick.AddListener(ToggleDarkenScene);
    }

    private IEnumerator HideLevelTextAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay); // Wait for the specified delay
        levelText.gameObject.SetActive(false); // Hide level text
    }

    void ResetLevel()
    {
        path.Clear(); // Clear the path
        gameEnded = false; // Reset game ended flag

        // Start the timer if there are targets remaining
        if (currentTargetIndex < targetObjects.Count)
        {
            startTime = Time.time; // Start timer for the current target
            SetTargetCell(currentTargetIndex); // Set the current target cell
            InitializeDynamicLighting(); // Set up lighting for the new target
        }
        else
        {
            Debug.Log("All targets have been found!"); // Log when all targets are found
            DisplayTimesTaken(); // Display times after all targets are found
            return; // Exit the method if all targets are found
        }

        // Clear time text when resetting level
        if (timeText != null)
            timeText.text = "";
    }

    void InitializeDynamicLighting()
    {
        if (roomLight != null)
            originalRoomLightIntensity = roomLight.intensity; // Store original intensity
        roomLight.intensity = 0.5f; // Set ambient light intensity

        if (targetLight != null)
        {
            originalTargetLightIntensity = targetLight.intensity; // Store original intensity
            targetLight.intensity = 0; // Turn off target light initially
        }
    }

    void CreateGrid()
    {
        int cellCounter = 1; // Counter for cells
        for (int x = 0; x < gridWidth; x++)
        {
            for (int y = 0; y < gridHeight; y++)
            {
                GameObject gridCellObject = Instantiate(gridCellPrefab, gridParent);
                gridCellObject.name = "Cell_" + x + "_" + y; // Name each cell uniquely

                RectTransform cellRectTransform = gridCellObject.GetComponent<RectTransform>();
                cellRectTransform.anchoredPosition = new Vector2(x * cellRectTransform.rect.width, y * cellRectTransform.rect.height);

                GridCell gridCell = gridCellObject.GetComponent<GridCell>();
                gridCell.Initialize(x, y, cellCounter, Color.red, Color.yellow, this); // Initialize each grid cell

                cellCounter++; // Increment cell counter
            }
        }
    }

    public void SetTargetCell(int targetIndex)
    {
        GameObject target = targetObjects[targetIndex]; // Get the current target
        RectTransform targetRectTransform = target.GetComponent<RectTransform>();
        RectTransform cellRectTransform = gridParent.GetComponent<RectTransform>();

        float cellWidth = gridCellPrefab.GetComponent<RectTransform>().rect.width; // Get cell width
        float cellHeight = gridCellPrefab.GetComponent<RectTransform>().rect.height; // Get cell height

        // Set target's position within the grid
        targetRectTransform.SetParent(gridParent);
        targetRectTransform.anchorMin = new Vector2(0, 0);
        targetRectTransform.anchorMax = new Vector2(0, 0);
        targetRectTransform.pivot = new Vector2(0.5f, 0.5f);

        int x = Random.Range(0, gridWidth); // Randomize target's position
        int y = Random.Range(0, gridHeight);
        targetRectTransform.anchoredPosition = new Vector2(x * cellWidth, y * cellHeight);

        GridCell gridCell = target.AddComponent<GridCell>(); // Add GridCell component to the target
        gridCell.Initialize(x, y, 0, Color.red, Color.yellow, this); // Initialize target cell

        currentTargetCell = gridCell; // Set the current target cell
    }

    public void AddCellToPath(GridCell cell)
    {
        if (!path.Contains(cell)) // Check if cell is already in path
        {
            cell.SetCellNumber(path.Count + 1); // Set cell number
            path.Add(cell); // Add cell to path
        }
    }

    public void OnTargetFound()
    {
        if (gameEnded) return; // Exit if the game has ended

        float timeTaken = Time.time - startTime; // Calculate time taken for the current target
        timesTaken.Add(timeTaken); // Store the time taken for this target
        timeText.text = "Time Taken: " + timeTaken.ToString("F2") + " seconds"; // Update the text

        // Prepare row data for CSV
        List<string> rowData = new List<string>
        {
            "Level " + (currentTargetIndex + 1), // Level
            "Target " + (currentTargetIndex + 1), // Target
            string.Join(" -> ", path.ConvertAll(cell => $"({cell.x},{cell.y})")), // Path taken
            timeTaken.ToString("F2"), // Time taken
            path.Count.ToString() // Number of grid cells in the path
        };

        // Save the data to CSV
        csvManager.SaveToCSV(rowData);

        currentTargetIndex++; // Move to the next target

        // Check if we have found all targets
        if (currentTargetIndex >= targetObjects.Count)
        {
            gameEnded = true; // Mark game as ended
            StartCoroutine(HandleFinalTargetFound()); // Handle final target found event
        }
        else
        {
            StartCoroutine(HandleTargetFound()); // Handle target found event
        }
    }



    // Ensure you have this helper function to get the path for each target
    private List<Vector2Int> GetPathForTarget(int targetIndex)
    {
        // Logic to retrieve the path for the target based on the target index
        List<Vector2Int> path = new List<Vector2Int>();

        // Example (replace with actual logic to retrieve the path)
        if (targetIndex == 0)
        {
            path.Add(new Vector2Int(0, 0));
            path.Add(new Vector2Int(1, 1)); // Add more path coordinates
        }

        return path;
    }



    IEnumerator HandleFinalTargetFound()
    {
        // Highlight the path for the final target found
        foreach (GridCell cell in path)
        {
            cell.SetCellColor(new Color32(255, 0, 255, 128)); // Set path cells to magenta with transparency
        }

        if (targetLight != null)
        {
            targetLight.intensity = 2.0f; // Increase target light intensity
            targetLight.transform.position = targetObjects[currentTargetIndex - 1].transform.position; // Move light to current target position
        }

        // Display the time taken for the last target for 2 seconds
        timeText.text = "Final Time: " + timesTaken[timesTaken.Count - 1].ToString("F2") + " seconds";
        yield return new WaitForSeconds(2); // Pause for 2 seconds to display the time

        // Show Game Over text and highlight Go Back button
        ShowGameOverScreen();
    }

    IEnumerator HandleTargetFound()
    {
        // Highlight path for 2 seconds
        foreach (GridCell cell in path)
        {
            cell.SetCellColor(new Color32(255, 0, 255, 128)); // Set path cells to magenta with transparency
        }

        if (targetLight != null)
        {
            targetLight.intensity = 2.0f; // Increase target light intensity
            targetLight.transform.position = targetObjects[currentTargetIndex].transform.position; // Move light to current target position
        }

        yield return new WaitForSeconds(2); // Pause for 2 seconds to display the path

        // Reset for next target
        foreach (GridCell cell in path)
        {
            cell.SetCellColor(Color.clear); // Clear the path cells
            cell.SetCellNumber(0); // Reset cell numbers
        }
        path.Clear(); // Clear the path list

        ResetLevel(); // Reset the grid and timer for the next target
    }

    void DisplayTimesTaken()
    {
        // Display all recorded times taken
        for (int i = 0; i < timesTaken.Count; i++)
        {
            Debug.Log("Time taken for target " + (i + 1) + ": " + timesTaken[i].ToString("F2") + " seconds");
        }
    }

    void ShowGameOverScreen()
    {
        gameOverText.gameObject.SetActive(true); // Show game over text
        gameOverText.text = "Game Over!"; // Set game over message
        goBackButton.SetActive(true); // Show Go Back button
    }

    public void ToggleDarkenScene()
    {
        Debug.Log("Toggling darken scene: " + isSceneDarkened);
        if (isSceneDarkened)
        {
            ResetScene(); // Restore original lighting if the scene is darkened
            Debug.Log("Resetting scene.");
        }
        else
        {
            DarkenScene(); // Darken the scene if it's not already darkened
            Debug.Log("Darkening scene.");
        }

        // Toggle the state
        isSceneDarkened = !isSceneDarkened;
    }


    void DarkenScene()
    {
        // Activate the dark overlay panel
        if (darkOverlay != null)
        {
            darkOverlay.SetActive(true);
        }
        // Reset cell colors
        foreach (GridCell cell in path)
        {
            cell.SetCellColor(Color.clear); // Clear previous cell colors
        }
        // Highlight the cell under the cursor
        Vector3 mousePos = Input.mousePosition; // Get the current mouse position
        Ray ray = Camera.main.ScreenPointToRay(mousePos); // Create a ray from the mouse position
        RaycastHit hit; // Variable for raycast hit

        if (Physics.Raycast(ray, out hit))
        {
            // Calculate the position of the cell to illuminate
            GameObject hitObject = hit.collider.gameObject;
            GridCell gridCell = hitObject.GetComponent<GridCell>();

            if (gridCell != null)
            {
                // Set the color of the hovered cell to its normal state
                gridCell.SetCellColor(Color.white); // Change color to white or your normal color
            }
        }
    }

    public void ResetScene()
    {
        // Disable the dark overlay
        if (darkOverlay != null)
        {
            darkOverlay.SetActive(false); // Deactivate the overlay
        }

        // Restore the original lighting conditions
        if (roomLight != null)
        {
            roomLight.intensity = originalRoomLightIntensity; // Restore original intensity
            roomLight.color = originalRoomLightColor; // Restore original color
        }

        // Reset highlighted cells if needed
        foreach (GridCell cell in path)
        {
            cell.SetCellColor(Color.clear); // Clear cell color
        }

        path.Clear(); // Clear the path list
    }

}